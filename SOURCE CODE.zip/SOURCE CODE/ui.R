library(shiny)
library(shinydashboard)
library(shinythemes)
library(shinyjs)
ui<-dashboardPage(
  dashboardHeader(title = "ploty Analysis"),
  dashboardSidebar(sidebarMenu(
    menuItem("Home",tabName = "Home",icon = icon("dashboard")),
    menuItem("Plots", tabName = "Plots", icon = icon("bar-chart-o")),
    menuItem("Table", tabName = "Table", icon = icon("table")),
    menuItem("Treanding", tabName = "Treanding", icon = icon("line-chart")),
    menuItem("Top Tweeters", tabName = "Top" , icon = icon("level-up"))
    
    
    
    
    
    
           )
  ),
  
  dashboardBody(
    tabItems(
      tabItem(tabName = "Home",
              fluidRow(
                box(title = "controls",status = "warning",height = 150,
                    textInput(inputId = "searchTerm", label = "Enter keyword", placeholder = "keyword",value="Samsung")),
                
                   box(status = "warning", sliderInput(inputId="maxTweets",label = "Tweets",min=10,max=1000,animate = TRUE,value = 200,step = 50)
                    ,p(
                      class="test-muted",
                      paste("Select the number of Tweets to analyse")
                    ),
                    submitButton(text= "Search")
                )),
              fluidRow(
                box(title="polarity",status = "warning",width =4 , plotOutput("histPos"),downloadButton("downloadData", "Download")),
                box(title="polarity",status = "warning",width = 4, plotOutput("histNeg")),
                box(title="Emotions",status = "warning",width=4,plotOutput("histScore"))
                
                
                
              )
              
      )
      ,
      tabItem(tabName = "Plots",
              
              h2("Data Visualization using Pie Chart And Word Cloud"),
              fluidRow(
                box( title="PieChart", status = "warning",  collapsible = TRUE,plotOutput("piechart")),
                box( title="Word Cloud", status = "warning",  collapsible = TRUE,plotOutput("word")
                
              )
              
      )
    ),
    tabItem(tabName = "Table",
            
            h2("Tweets Streamed For Sentimental Analysis"),
            fluidRow(
              box( title="Tweet Table",width = "100%", status = "warning",  collapsible = TRUE, dataTableOutput("tabledata"))
              
                   
              )
              
            ),
    tabItem(tabName = "Treanding",
            
            h2("Tweets Treanding Today"),
            fluidRow(
              box(align="center", title="Tranding",solidHeader =TRUE ,status = "info",collapsible = TRUE,column(8,align="center", tableOutput("trendtable")))
              
              
            )),
    
    
    tabItem(tabName = "Top",
            
            h2("Top Tweeters of the product"),
            fluidRow(
              box( title="Tweeters",solidHeader =TRUE , width=8, status = "warning",collapsible = TRUE,plotOutput("tweetersplot")),
             box( title="Tweeters",solidHeader =TRUE ,width=4,status = "warning",collapsible = TRUE,tableOutput("tweeterstable"))
              
              
            ))
    ),
    useShinyjs() )
    
  )






